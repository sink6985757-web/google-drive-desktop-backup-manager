﻿#requires -version 5.1
[CmdletBinding()]
param([switch]$Force)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'Common.ps1')
$DriveSetupUrl = 'https://dl.google.com/drive-file-stream/GoogleDriveSetup.exe'
$existing = Get-GoogleDriveExe
if ($existing -and -not $Force) { Write-AppPass "已安裝：$existing"; exit 0 }
$tempDir = Join-Path $env:TEMP ('gddbm_drive_' + [guid]::NewGuid().ToString('N'))
$setup = Join-Path $tempDir 'GoogleDriveSetup.exe'
New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
try {
    Write-AppInfo '從 Google 官方下載最新版...'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -UseBasicParsing -Uri $DriveSetupUrl -OutFile $setup
    $sig = Get-AuthenticodeSignature -FilePath $setup
    if ($sig.Status -ne 'Valid' -or -not $sig.SignerCertificate -or $sig.SignerCertificate.Subject -notmatch 'Google') {
        throw "數位簽章驗證失敗：$($sig.Status) / $($sig.SignerCertificate.Subject)"
    }
    Write-AppPass "簽章通過：$($sig.SignerCertificate.Subject)"
    $p = Start-Process -FilePath $setup -ArgumentList '--silent --desktop_shortcut' -Wait -PassThru
    if ($p.ExitCode -notin @(0,3010)) { throw "安裝失敗，ExitCode=$($p.ExitCode)" }
    $exe = $null
    for ($i = 0; $i -lt 30 -and -not $exe; $i++) {
        Start-Sleep -Seconds 1
        $exe = Get-GoogleDriveExe
    }
    if (-not $exe) { throw '安裝後 30 秒內仍找不到 GoogleDriveFS.exe。' }
    Start-Process -FilePath $exe | Out-Null
    Write-AppPass "安裝／修復完成：$exe"
} finally { Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue }
