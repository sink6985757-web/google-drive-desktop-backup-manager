﻿#requires -version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'Common.ps1')

$config = Get-AppConfig
$recycleRoot = Join-Path "$($config.BackupRootPath)" "$($config.MirrorSafety.RecycleFolderName)"
New-Item -ItemType Directory -Path $recycleRoot -Force | Out-Null
Write-Host ''
Write-Host '=== MirrorSafe 回收區管理 ===' -ForegroundColor White
Write-Host "位置：$recycleRoot"
Write-Host "保留天數設定：$($config.MirrorSafety.RecycleRetentionDays) 天"
$cutoff = (Get-Date).AddDays(-[int]$config.MirrorSafety.RecycleRetentionDays)
$snapshots = Get-ChildItem -LiteralPath (Join-Path $recycleRoot 'GDDM_MirrorSafe') -Directory -ErrorAction SilentlyContinue |
    Where-Object { $_.LastWriteTime -lt $cutoff } | Sort-Object LastWriteTime
$totalBytes = [int64]0
foreach ($snapshot in $snapshots) {
    $bytes = [int64](Get-ChildItem -LiteralPath $snapshot.FullName -File -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
    $totalBytes += $bytes
    Write-Host ("{0}  {1} bytes  {2}" -f $snapshot.LastWriteTime.ToString('yyyy-MM-dd HH:mm'),$bytes,$snapshot.FullName)
}
if (@($snapshots).Count -eq 0) {
    Write-AppPass '沒有超過保留天數的 MirrorSafe 回收快照。'
    exit 0
}
Write-AppWarn "共 $(@($snapshots).Count) 個過期快照，$totalBytes bytes。預設不會自動刪除。"
$confirm = Read-Host '輸入 PURGE RECYCLE 才會永久刪除以上過期快照'
if ($confirm -ne 'PURGE RECYCLE') { Write-AppInfo '已取消；回收區未變更。'; exit 0 }
foreach ($snapshot in $snapshots) {
    Remove-Item -LiteralPath $snapshot.FullName -Recurse -Force
    Write-AppPass "已刪除：$($snapshot.FullName)"
}
