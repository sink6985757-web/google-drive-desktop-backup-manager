﻿#requires -version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ListPath = Join-Path $Root 'SHA256SUMS.txt'
if (-not (Test-Path -LiteralPath $ListPath)) { throw "找不到：$ListPath" }
$failed = @()
$checked = 0
foreach ($line in Get-Content -LiteralPath $ListPath -Encoding UTF8) {
    if ($line -notmatch '^([0-9a-fA-F]{64})\s{2}(.+)$') { continue }
    $expected = $matches[1].ToLowerInvariant()
    $relative = $matches[2].Replace('/', [IO.Path]::DirectorySeparatorChar)
    $file = Join-Path $Root $relative
    if (-not (Test-Path -LiteralPath $file -PathType Leaf)) {
        $failed += "遺失：$relative"
        continue
    }
    $actual = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant()
    $checked++
    if ($actual -ne $expected) { $failed += "雜湊不符：$relative" }
}
if ($failed.Count -gt 0) {
    $failed | ForEach-Object { Write-Host "[FAIL] $_" -ForegroundColor Red }
    throw "安裝包完整性驗證失敗，共 $($failed.Count) 項。"
}
Write-Host "[PASS] 安裝包完整性驗證通過，共檢查 $checked 個檔案。" -ForegroundColor Green
