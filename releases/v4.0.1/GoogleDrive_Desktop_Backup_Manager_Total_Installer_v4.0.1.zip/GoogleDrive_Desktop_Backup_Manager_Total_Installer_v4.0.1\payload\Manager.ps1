﻿#requires -version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'Common.ps1')

function Pause-App { Write-Host ''; [void](Read-Host '按 Enter 返回主選單') }

while ($true) {
    Clear-Host
    $cfg = $null
    try { $cfg = Get-AppConfig } catch { }
    Write-Host 'Google Drive Desktop Backup Manager v4.0.1' -ForegroundColor White
    Write-Host '========================================'
    if ($cfg) {
        Write-Host "目前模式：$($cfg.SyncMode)"
        Write-Host "備份根目錄：$($cfg.BackupRootPath)"
        Write-Host "排程：$($cfg.Schedule.Enabled) / $($cfg.Schedule.Mode) / $($cfg.Schedule.Time)"
    }
    Write-Host ''
    Write-Host '1. 首次設定／修改設定'
    Write-Host '2. 驗證環境與設定'
    Write-Host '3. CopySafe 安全模擬（不寫入）'
    Write-Host '4. CopySafe 立即備份'
    Write-Host '5. MirrorSafe 產生鏡像預覽計畫'
    Write-Host '6. MirrorSafe 執行最新鏡像計畫'
    Write-Host '7. 排程管理'
    Write-Host '8. 開啟備份目標'
    Write-Host '9. 開啟 99_recycle 回收區'
    Write-Host '10. 查看最新日誌／計畫'
    Write-Host '11. 回收區清理管理'
    Write-Host '12. 安裝／修復 Google 雲端硬碟電腦版'
    Write-Host '13. 解除安裝'
    Write-Host '0. 結束'
    Write-Host ''
    $choice = Read-Host '請選擇'
    switch ($choice) {
        '1' { & (Join-Path $script:AppRoot 'Configure.ps1'); Pause-App }
        '2' {
            $mode = if ($cfg) { "$($cfg.SyncMode)" } else { 'CopySafe' }
            & (Join-Path $script:AppRoot 'Backup.ps1') -Mode $mode -ValidateOnly
            Pause-App
        }
        '3' { & (Join-Path $script:AppRoot 'Backup.ps1') -Mode CopySafe -DryRun; Pause-App }
        '4' {
            Write-AppWarn 'CopySafe 只新增或更新目標內容，不處理目標中的額外檔案。'
            $ok = Read-Host '輸入 YES 開始 CopySafe 正式備份'
            if ($ok -eq 'YES') { & (Join-Path $script:AppRoot 'Backup.ps1') -Mode CopySafe } else { Write-AppInfo '已取消。' }
            Pause-App
        }
        '5' { & (Join-Path $script:AppRoot 'Backup.ps1') -Mode MirrorSafe -DryRun; Pause-App }
        '6' {
            try {
                $latest = Join-Path $script:PlansRoot 'latest_mirror_plan.json'
                if (-not (Test-Path -LiteralPath $latest)) { throw '尚無鏡像計畫，請先執行選項 5。' }
                $plan = Get-Content -LiteralPath $latest -Raw -Encoding UTF8 | ConvertFrom-Json
                Write-Host "PlanId：$($plan.PlanId)"
                Write-Host "建立時間：$($plan.CreatedAt)"
                Write-Host "受影響項目：$($plan.TotalAffectedItems)"
                Write-Host "受影響檔案：$($plan.TotalAffectedFiles)"
                Write-Host "受影響容量：$($plan.TotalAffectedBytes) bytes"
                Write-Host "最大比例：$($plan.MaxAffectedPercent)%"
                if ([bool]$plan.IsBlocked) { throw '此計畫已被安全門檻阻擋，不能執行。' }
                Write-AppWarn '目標額外項目會移到 99_recycle，不會永久刪除。執行前會重新掃描，若內容改變即拒絕。'
                $confirm = Read-Host "輸入 MIRROR $($plan.PlanId) 確認"
                if ($confirm -eq "MIRROR $($plan.PlanId)") {
                    & (Join-Path $script:AppRoot 'Backup.ps1') -Mode MirrorSafe -ApprovePlanId "$($plan.PlanId)"
                } else { Write-AppInfo '已取消。' }
            } catch { Write-AppError $_.Exception.Message }
            Pause-App
        }
        '7' {
            Write-Host '1. 查看排程  2. 依設定建立／更新排程  3. 移除排程'
            $s = Read-Host '請選擇'
            if ($s -eq '1') { & (Join-Path $script:AppRoot 'Schedule_Manager.ps1') -Action Status }
            elseif ($s -eq '2') { & (Join-Path $script:AppRoot 'Schedule_Manager.ps1') -Action Install }
            elseif ($s -eq '3') { & (Join-Path $script:AppRoot 'Schedule_Manager.ps1') -Action Remove }
            Pause-App
        }
        '8' {
            try { if ($cfg -and $cfg.BackupRootPath) { Start-Process explorer.exe -ArgumentList ('"' + $cfg.BackupRootPath + '"') } else { Write-AppWarn '尚未設定目標。' } } catch { Write-AppError $_.Exception.Message }
            Pause-App
        }
        '9' {
            try {
                if (-not $cfg) { throw '無法讀取設定。' }
                $path = Join-Path "$($cfg.BackupRootPath)" "$($cfg.MirrorSafety.RecycleFolderName)"
                New-Item -ItemType Directory -Path $path -Force | Out-Null
                Start-Process explorer.exe -ArgumentList ('"' + $path + '"')
            } catch { Write-AppError $_.Exception.Message }
            Pause-App
        }
        '10' {
            Write-Host '1. 最新日誌  2. 最新鏡像計畫'
            $v = Read-Host '請選擇'
            if ($v -eq '2') {
                $latestPlan = Join-Path $script:PlansRoot 'latest_mirror_plan.json'
                if (Test-Path -LiteralPath $latestPlan) { Start-Process notepad.exe -ArgumentList ('"' + $latestPlan + '"') } else { Write-AppWarn '尚無鏡像計畫。' }
            } else {
                $latestLog = Get-ChildItem -LiteralPath $script:LogsRoot -Filter '*.log' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
                if ($latestLog) { Start-Process notepad.exe -ArgumentList ('"' + $latestLog.FullName + '"') } else { Write-AppWarn '尚無日誌。' }
            }
            Pause-App
        }
        '11' { & (Join-Path $script:AppRoot 'Recycle_Manager.ps1'); Pause-App }
        '12' { & (Join-Path $script:AppRoot 'Install_GoogleDrive_Desktop.ps1') -Force; Pause-App }
        '13' { & (Join-Path $script:AppRoot 'Uninstall.ps1'); exit }
        '0' { exit }
        default { Write-AppWarn '選項無效。'; Start-Sleep -Seconds 1 }
    }
}
