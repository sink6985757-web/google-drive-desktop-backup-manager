﻿#requires -version 5.1
[CmdletBinding()]
param(
    [ValidateSet('Install','Remove','Status')][string]$Action = 'Status',
    [switch]$Quiet
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'Common.ps1')
$config = Get-AppConfig

switch ($Action) {
    'Status' {
        $task = Get-ScheduledTask -TaskName $script:TaskName -ErrorAction SilentlyContinue
        if ($task) { $task | Get-ScheduledTaskInfo | Format-List * } else { Write-AppInfo '尚未建立排程。' }
    }
    'Remove' {
        Unregister-ScheduledTask -TaskName $script:TaskName -Confirm:$false -ErrorAction SilentlyContinue
        $config.Schedule.Enabled = $false
        Save-AppConfig $config
        if (-not $Quiet) { Write-AppPass '排程已移除；手動備份與鏡像功能保留。' }
    }
    'Install' {
        $timeText = "$($config.Schedule.Time)"
        if ($timeText -notmatch '^([01]\d|2[0-3]):[0-5]\d$') { throw "排程時間格式錯誤：$timeText" }
        $at = [datetime]::ParseExact($timeText, 'HH:mm', [Globalization.CultureInfo]::InvariantCulture)
        $backupScript = Join-Path $script:AppRoot 'Backup.ps1'
        $mode = "$($config.Schedule.Mode)"
        switch ($mode) {
            'MirrorPreview' { $arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$backupScript`" -Mode MirrorSafe -DryRun -Scheduled" }
            'MirrorSafeAuto' {
                if (-not [bool]$config.MirrorSafety.AllowScheduledMirror) { throw '設定未允許排程自動鏡像。' }
                $arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$backupScript`" -Mode MirrorSafe -AutoApprove -Scheduled"
            }
            default {
                $mode = 'CopySafe'
                $arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$backupScript`" -Mode CopySafe -Scheduled"
            }
        }
        $actionObject = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $arguments -WorkingDirectory $script:AppRoot
        $trigger = New-ScheduledTaskTrigger -Daily -At $at
        $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Hours 12)
        $userId = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        $principal = New-ScheduledTaskPrincipal -UserId $userId -LogonType Interactive -RunLevel Limited
        Register-ScheduledTask -TaskName $script:TaskName -Action $actionObject -Trigger $trigger -Settings $settings -Principal $principal -Description "Google Drive Desktop Backup Manager v4 - $mode" -Force | Out-Null
        $config.Schedule.Enabled = $true
        $config.Schedule.Mode = $mode
        Save-AppConfig $config
        Write-AppPass "每日排程已建立：$timeText，模式=$mode（使用者登入時執行）"
    }
}
