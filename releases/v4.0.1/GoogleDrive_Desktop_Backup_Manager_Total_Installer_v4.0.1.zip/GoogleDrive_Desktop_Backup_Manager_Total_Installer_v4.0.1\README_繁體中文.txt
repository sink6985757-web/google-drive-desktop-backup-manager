﻿Google Drive Desktop Backup Manager v4.0.1 - MirrorSafe Portable
===========================================================

用途
----
這是一套 Windows 10/11 的 Google Drive 本機備份／安全鏡像管理器，使用：
1. Google 官方「Google 雲端硬碟電腦版」
2. Windows 內建 Robocopy
3. v4 自建 MirrorSafe 計畫、門檻、回收區與執行後驗證

不需要 rclone、不需要 Google Cloud Client ID，也不需要自建 OAuth。
安裝包不含任何使用者名稱、私人磁碟路徑或 Google Drive 檔案清單。

v4 核心模式
------------
1. CopySafe（預設）
   - 本機是正式來源。
   - 只新增或更新 Google Drive 掛載目標。
   - 不處理目標額外檔案。

2. MirrorSafe
   - 先掃描本機與目標，產生 PlanId 與完整預覽計畫。
   - 目標中已不在本機的舊位置，不永久刪除，而是移入：
     <備份根目錄>\99_recycle\GDDM_MirrorSafe\日期時間_PlanId
   - 再以 Robocopy /E 複製新增及更新內容。
   - 執行後重新掃描，確認目標額外項目歸零，並做唯讀 Robocopy 驗證。

MirrorSafe 安全門檻
-------------------
預設值：
- 單次最多受影響項目：20
- 單一來源最多受影響比例：2%
- 單次最多移入回收區：5 GB
- 目標已有資料時，來源至少必須有 1 個檔案
- 計畫有效期：24 小時
- 執行前重新掃描；來源或目標改變後 PlanId 會不同，舊計畫不能執行
- 保護 sync.ffs_db 與 .tmp.driveupload，不把它們當成應移除的目標額外項目
- 回收區預設保留 90 天，但不會自動永久刪除

安裝／升級
----------
1. 雙擊 Verify_Package.cmd 驗證安裝包。
2. 由 v3 升級：雙擊 Install.cmd。
   - 會先備份既有 Backup_Config.json、logs、state、config_backups。
   - 保留來源、Google Drive 目標與排程。
   - v3 升級後預設仍使用 CopySafe，不會立刻鏡像或移動雲端舊檔。
3. 全新安裝或完全重設：雙擊 Fresh_Install.cmd。

建議第一次使用 MirrorSafe
--------------------------
1. 從桌面開啟「Google Drive Backup Manager」。
2. 選 1，將同步模式改為 MirrorSafe，確認來源是目前裝置上真正的來源資料夾。
3. 選 2 驗證環境。
4. 選 5 產生 MirrorSafe 預覽計畫。
5. 查看 PlanId、受影響數量、比例與容量。
6. 如果超過門檻，程式會 BLOCK，不會移動任何檔案。
7. 確認正確後選 6，輸入畫面要求的「MIRROR PlanId」。
8. 完成後到 Google Drive 系統匣確認同步完成。
9. 到 99_recycle 確認舊路徑可復原。

排程模式
--------
- CopySafe：每天正式新增／更新，最保守，建議預設使用。
- MirrorPreview：每天只產生 MirrorSafe 預覽，不移動檔案。
- MirrorSafeAuto：自動安全鏡像，必須在設定精靈輸入 ENABLE AUTO MIRROR 才能啟用；仍受門檻保護。

重要限制
--------
- 本工具操作的是 Google Drive for desktop 掛載到 Windows 的資料夾；Google 雲端實際上傳、移動與版本由 Google Drive 背景完成。
- MirrorSafe 不是完全雙向同步。本機來源仍是唯一正式母資料。
- 雲端端的手動變更不會反向覆寫本機來源。
- 不要對同一組資料夾同時使用另一套鏡像工具，避免競爭與衝突。
- 第一次鏡像前必須先確認來源與目標路徑正確、相關磁碟區已掛載、Google Drive 已登入。

路徑與隱私
----------
- 首次設定會從目前使用者的文件資料夾開啟選擇器，不預設任何人的磁碟機或家目錄。
- 備份執行時必須使用 Windows 完整路徑；路徑只保存在本機 Backup_Config.json。
- 不要上傳 Backup_Config.json、logs、state、config_backups、Plan、Manifest 或回收快照。

解除安裝
--------
解除安裝管理器不會刪除：
- 本機來源資料
- Google Drive 雲端內容
- 備份目標
- 99_recycle 回收內容
- Google Drive 使用者設定或快取
