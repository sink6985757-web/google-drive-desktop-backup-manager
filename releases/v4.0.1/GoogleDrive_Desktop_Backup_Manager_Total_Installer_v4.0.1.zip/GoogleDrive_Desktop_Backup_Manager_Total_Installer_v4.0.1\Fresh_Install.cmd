@echo off
setlocal
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1" -Fresh
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo [ERROR] Installer exited with code %RC%.
pause
exit /b %RC%
