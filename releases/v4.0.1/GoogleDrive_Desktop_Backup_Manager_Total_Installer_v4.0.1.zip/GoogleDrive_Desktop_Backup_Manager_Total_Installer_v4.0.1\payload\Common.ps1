﻿#requires -version 5.1
Set-StrictMode -Version Latest
$script:AppVersion = '4.0.1'
$script:TaskName = 'GoogleDrive_Desktop_Backup_Manager'
$script:AppRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:ConfigPath = Join-Path $script:AppRoot 'Backup_Config.json'
$script:LogsRoot = Join-Path $script:AppRoot 'logs'
$script:StateRoot = Join-Path $script:AppRoot 'state'
$script:PlansRoot = Join-Path $script:StateRoot 'plans'
$script:ManifestsRoot = Join-Path $script:StateRoot 'manifests'

function Write-AppInfo([string]$Text) { Write-Host "[INFO] $Text" -ForegroundColor Cyan }
function Write-AppPass([string]$Text) { Write-Host "[PASS] $Text" -ForegroundColor Green }
function Write-AppWarn([string]$Text) { Write-Host "[WARN] $Text" -ForegroundColor Yellow }
function Write-AppError([string]$Text) { Write-Host "[ERROR] $Text" -ForegroundColor Red }

function Add-ObjectProperty {
    param([object]$Object, [string]$Name, [object]$Value)
    if (-not $Object.PSObject.Properties[$Name]) {
        $Object | Add-Member -NotePropertyName $Name -NotePropertyValue $Value
    }
}

function Get-DefaultMirrorSafety {
    return [pscustomobject]@{
        RequirePlanApproval = $true
        PlanValidityHours = 24
        MaxAffectedItems = 20
        MaxAffectedPercent = 2.0
        MaxRecycleBytesGB = 5.0
        MinSourceFilesWhenTargetHasData = 1
        RecycleFolderName = '99_recycle'
        RecycleRetentionDays = 90
        AutoPurgeRecycle = $false
        AllowScheduledMirror = $false
        ProtectedNames = @('sync.ffs_db', '.tmp.driveupload')
    }
}

function Upgrade-AppConfig([object]$Config) {
    if (-not $Config) { throw '設定物件為空。' }
    Add-ObjectProperty -Object $Config -Name 'SchemaVersion' -Value 4
    Add-ObjectProperty -Object $Config -Name 'ApplicationVersion' -Value $script:AppVersion
    Add-ObjectProperty -Object $Config -Name 'SyncMode' -Value 'CopySafe'
    Add-ObjectProperty -Object $Config -Name 'BackupRootPath' -Value ''
    Add-ObjectProperty -Object $Config -Name 'VerifyAfterCopy' -Value $true
    Add-ObjectProperty -Object $Config -Name 'LogRetentionDays' -Value 60
    Add-ObjectProperty -Object $Config -Name 'Sources' -Value @()
    if (-not $Config.PSObject.Properties['CopyOptions'] -or -not $Config.CopyOptions) {
        $Config.CopyOptions = [pscustomobject]@{ Retries = 2; WaitSeconds = 5; Threads = 8 }
    } else {
        Add-ObjectProperty -Object $Config.CopyOptions -Name 'Retries' -Value 2
        Add-ObjectProperty -Object $Config.CopyOptions -Name 'WaitSeconds' -Value 5
        Add-ObjectProperty -Object $Config.CopyOptions -Name 'Threads' -Value 8
    }
    if (-not $Config.PSObject.Properties['MirrorSafety'] -or -not $Config.MirrorSafety) {
        $Config | Add-Member -NotePropertyName MirrorSafety -NotePropertyValue (Get-DefaultMirrorSafety) -Force
    } else {
        $defaults = Get-DefaultMirrorSafety
        foreach ($prop in $defaults.PSObject.Properties) {
            Add-ObjectProperty -Object $Config.MirrorSafety -Name $prop.Name -Value $prop.Value
        }
    }
    if (-not $Config.PSObject.Properties['Schedule'] -or -not $Config.Schedule) {
        $Config.Schedule = [pscustomobject]@{ Enabled = $false; Time = '02:00'; Mode = 'CopySafe' }
    } else {
        Add-ObjectProperty -Object $Config.Schedule -Name 'Enabled' -Value $false
        Add-ObjectProperty -Object $Config.Schedule -Name 'Time' -Value '02:00'
        Add-ObjectProperty -Object $Config.Schedule -Name 'Mode' -Value 'CopySafe'
    }
    $Config.SchemaVersion = 4
    $Config.ApplicationVersion = $script:AppVersion
    if ("$($Config.SyncMode)" -notin @('CopySafe','MirrorSafe')) { $Config.SyncMode = 'CopySafe' }
    if ("$($Config.Schedule.Mode)" -notin @('CopySafe','MirrorPreview','MirrorSafeAuto')) { $Config.Schedule.Mode = 'CopySafe' }
    return $Config
}

function Get-AppConfig {
    if (-not (Test-Path -LiteralPath $script:ConfigPath)) { throw "找不到設定檔：$script:ConfigPath" }
    $config = Get-Content -LiteralPath $script:ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $config = Upgrade-AppConfig $config
    return $config
}

function Save-AppConfig([object]$Config) {
    $Config = Upgrade-AppConfig $Config
    $Config.ApplicationVersion = $script:AppVersion
    $Config.SchemaVersion = 4
    $Config | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $script:ConfigPath -Encoding UTF8
}

function Get-GoogleDriveExe {
    $roots = @(
        (Join-Path $env:ProgramFiles 'Google\Drive File Stream'),
        (Join-Path $env:LOCALAPPDATA 'Google\DriveFS')
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
    foreach ($root in $roots) {
        $exe = Get-ChildItem -LiteralPath $root -Filter 'GoogleDriveFS.exe' -File -Recurse -ErrorAction SilentlyContinue |
            Sort-Object { $_.Directory.Name } -Descending | Select-Object -First 1
        if ($exe) { return $exe.FullName }
    }
    return $null
}

function Start-GoogleDriveIfNeeded {
    $exe = Get-GoogleDriveExe
    if (-not $exe) { throw '尚未安裝 Google 雲端硬碟電腦版。請從管理器執行安裝／修復。' }
    if (-not (Get-Process -Name GoogleDriveFS -ErrorAction SilentlyContinue)) {
        Start-Process -FilePath $exe | Out-Null
        Start-Sleep -Seconds 4
    }
    return $exe
}

function Test-WritableFolder([string]$Path) {
    try {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
        $probe = Join-Path $Path ('.gddbm_write_test_' + [guid]::NewGuid().ToString('N') + '.tmp')
        Set-Content -LiteralPath $probe -Value 'write-test' -Encoding ASCII
        Remove-Item -LiteralPath $probe -Force
        return $true
    } catch { return $false }
}

function Get-NormalizedPath([string]$Path) {
    return [IO.Path]::GetFullPath($Path).TrimEnd('\')
}

function Test-PathOverlap([string]$PathA, [string]$PathB) {
    $a = (Get-NormalizedPath $PathA) + '\'
    $b = (Get-NormalizedPath $PathB) + '\'
    return $a.StartsWith($b, [StringComparison]::OrdinalIgnoreCase) -or $b.StartsWith($a, [StringComparison]::OrdinalIgnoreCase)
}

function Get-RelativeChildPath([string]$Root, [string]$FullName) {
    $rootNorm = (Get-NormalizedPath $Root) + '\'
    $fullNorm = [IO.Path]::GetFullPath($FullName)
    if (-not $fullNorm.StartsWith($rootNorm, [StringComparison]::OrdinalIgnoreCase)) {
        throw "路徑不在根目錄內：$FullName"
    }
    return $fullNorm.Substring($rootNorm.Length)
}

function Get-StringSha256([string]$Text) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [Text.Encoding]::UTF8.GetBytes($Text)
        return (($sha.ComputeHash($bytes) | ForEach-Object { $_.ToString('x2') }) -join '')
    } finally { $sha.Dispose() }
}

function Test-ProtectedRelativePath {
    param([string]$RelativePath, [object]$MirrorSafety)
    if (-not $RelativePath) { return $false }
    $segments = $RelativePath -split '[\\/]'
    $protected = @($MirrorSafety.ProtectedNames | ForEach-Object { "$_" })
    foreach ($segment in $segments) {
        foreach ($name in $protected) {
            if ($segment.Equals($name, [StringComparison]::OrdinalIgnoreCase)) { return $true }
        }
    }
    return $false
}

function Get-PathDepth([string]$RelativePath) {
    if (-not $RelativePath) { return 0 }
    return (@($RelativePath -split '[\\/]' | Where-Object { $_ }).Count)
}

function Test-RelativePathUnder([string]$Child, [string]$Parent) {
    if (-not $Parent) { return $false }
    $p = $Parent.TrimEnd('\','/') + '\'
    $c = $Child.Replace('/','\')
    return $c.StartsWith($p, [StringComparison]::OrdinalIgnoreCase)
}
