﻿#requires -version 5.1
[CmdletBinding()]
param([switch]$FirstRun)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'Common.ps1')

function Select-Folder {
    param([string]$Description, [string]$InitialPath = '')
    try {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = $Description
        $dialog.ShowNewFolderButton = $true
        if ($InitialPath -and (Test-Path -LiteralPath $InitialPath)) { $dialog.SelectedPath = $InitialPath }
        $result = $dialog.ShowDialog()
        if ($result -eq [System.Windows.Forms.DialogResult]::OK) { return $dialog.SelectedPath }
    } catch { Write-AppWarn "資料夾選擇視窗無法開啟：$($_.Exception.Message)" }
    $manual = Read-Host "$Description（請輸入完整路徑）"
    return $manual.Trim().Trim('"')
}

function Read-YesNo([string]$Prompt, [bool]$Default = $false) {
    $suffix = if ($Default) { '[Y/n]' } else { '[y/N]' }
    $v = Read-Host "$Prompt $suffix"
    if (-not $v.Trim()) { return $Default }
    return $v -match '^[Yy]'
}

function Read-Int([string]$Prompt, [int]$Default, [int]$Minimum, [int]$Maximum) {
    while ($true) {
        $v = Read-Host "$Prompt [$Default]"
        if (-not $v.Trim()) { return $Default }
        $parsed = 0
        if ([int]::TryParse($v, [ref]$parsed) -and $parsed -ge $Minimum -and $parsed -le $Maximum) { return $parsed }
        Write-AppWarn "請輸入 $Minimum 到 $Maximum 的整數。"
    }
}

function Read-Double([string]$Prompt, [double]$Default, [double]$Minimum, [double]$Maximum) {
    while ($true) {
        $v = Read-Host "$Prompt [$Default]"
        if (-not $v.Trim()) { return $Default }
        $parsed = 0.0
        if ([double]::TryParse($v, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$parsed) -and $parsed -ge $Minimum -and $parsed -le $Maximum) { return $parsed }
        Write-AppWarn "請輸入 $Minimum 到 $Maximum 的數值，使用小數點。"
    }
}

Write-Host ''
Write-Host '=== Google Drive Desktop Backup Manager v4 設定 ===' -ForegroundColor White
$driveExe = Start-GoogleDriveIfNeeded
Write-AppPass "Google Drive 程式存在：$driveExe"
Write-AppInfo '若尚未登入 Google 帳號，請先在 Google Drive 官方視窗完成登入。'
[void](Read-Host '確認已登入，且檔案總管看得到「我的雲端硬碟」後按 Enter')

$config = Get-AppConfig
$sources = @()
$defaultSource = [Environment]::GetFolderPath('MyDocuments')
if (-not $defaultSource -or -not (Test-Path -LiteralPath $defaultSource -PathType Container)) {
    $defaultSource = $HOME
}
if (-not $FirstRun -and @($config.Sources).Count -gt 0) {
    if (Read-YesNo '保留目前來源資料夾設定？' $true) { $sources = @($config.Sources) }
}

if ($sources.Count -eq 0) {
    do {
        $sourcePath = Select-Folder -Description '選擇要備份的本機來源資料夾' -InitialPath $defaultSource
        if (-not $sourcePath -or -not (Test-Path -LiteralPath $sourcePath -PathType Container)) {
            Write-AppWarn '來源資料夾不存在，請重新選擇。'
            continue
        }
        $defaultName = Split-Path -Leaf $sourcePath.TrimEnd('\')
        $remoteName = Read-Host "此來源在備份根目錄中的資料夾名稱 [$defaultName]"
        if (-not $remoteName.Trim()) { $remoteName = $defaultName }
        if ($remoteName -match '[\\/:*?"<>|]') { throw "資料夾名稱含 Windows 不允許字元：$remoteName" }
        $sources += [pscustomobject]@{ Enabled = $true; LocalPath = $sourcePath; BackupFolder = $remoteName.Trim() }
        $defaultSource = Split-Path -Parent $sourcePath
    } while (Read-YesNo '還要新增另一個來源資料夾嗎？' $false)
}

$previousRoot = "$($config.BackupRootPath)"
$keepTarget = $false
if (-not $FirstRun -and $previousRoot -and (Test-Path -LiteralPath $previousRoot -PathType Container)) {
    $keepTarget = Read-YesNo "保留目前 Google Drive 備份根目錄？`n$previousRoot" $true
}
if ($keepTarget) {
    $backupRoot = $previousRoot
} else {
    $initialTarget = ''
    if ($previousRoot -and (Test-Path -LiteralPath $previousRoot)) { $initialTarget = Split-Path -Parent $previousRoot }
    $driveBase = Select-Folder -Description '選擇 Google Drive 中的「我的雲端硬碟」或指定同步資料夾' -InitialPath $initialTarget
    if (-not $driveBase -or -not (Test-Path -LiteralPath $driveBase -PathType Container)) { throw '未選擇有效的 Google Drive 目標資料夾。' }
    $defaultRootName = if ($previousRoot) { Split-Path -Leaf $previousRoot } else { 'D_Drive_Backup' }
    $rootName = Read-Host "備份根資料夾名稱 [$defaultRootName]"
    if (-not $rootName.Trim()) { $rootName = $defaultRootName }
    if ($rootName -match '[\\/:*?"<>|]') { throw "備份根資料夾名稱含 Windows 不允許字元：$rootName" }
    $backupRoot = Join-Path $driveBase $rootName.Trim()
}

foreach ($source in $sources) {
    if (Test-PathOverlap -PathA $source.LocalPath -PathB $backupRoot) { throw "來源與備份目標不能互相包含：$($source.LocalPath) <-> $backupRoot" }
}
if (-not (Test-WritableFolder $backupRoot)) { throw "Google Drive 目標無法寫入：$backupRoot" }
Write-AppPass "Google Drive 目標可寫入：$backupRoot"

Write-Host ''
Write-Host '同步模式：'
Write-Host '1. CopySafe：只新增／更新，不處理目標額外檔案（最保守）'
Write-Host '2. MirrorSafe：目標額外檔案先移入 99_recycle，再新增／更新（建議先預覽）'
$defaultMode = if ("$($config.SyncMode)" -eq 'MirrorSafe') { '2' } else { '1' }
$modeChoice = Read-Host "請選擇 [$defaultMode]"
if (-not $modeChoice.Trim()) { $modeChoice = $defaultMode }
$config.SyncMode = if ($modeChoice -eq '2') { 'MirrorSafe' } else { 'CopySafe' }

if ($config.SyncMode -eq 'MirrorSafe') {
    Write-AppWarn 'MirrorSafe 不會永久刪除；目標額外項目會移入 99_recycle。超過門檻會自動停止。'
    $config.MirrorSafety.MaxAffectedItems = Read-Int '單次最多允許受影響項目數' ([int]$config.MirrorSafety.MaxAffectedItems) 1 1000000
    $config.MirrorSafety.MaxAffectedPercent = Read-Double '單一來源最多允許受影響比例（%）' ([double]$config.MirrorSafety.MaxAffectedPercent) 0.01 100
    $config.MirrorSafety.MaxRecycleBytesGB = Read-Double '單次最多允許移入回收區容量（GB）' ([double]$config.MirrorSafety.MaxRecycleBytesGB) 0.01 100000
    $config.MirrorSafety.RequirePlanApproval = $true
}

$config.SchemaVersion = 4
$config.BackupRootPath = $backupRoot
$config.Sources = $sources
$config.VerifyAfterCopy = $true

$enableSchedule = Read-YesNo '是否建立每日自動工作？' ([bool]$config.Schedule.Enabled)
$config.Schedule.Enabled = $enableSchedule
if ($enableSchedule) {
    $defaultTime = if ("$($config.Schedule.Time)" -match '^([01]\d|2[0-3]):[0-5]\d$') { "$($config.Schedule.Time)" } else { '02:00' }
    do {
        $time = Read-Host "每日執行時間（24 小時制 HH:mm）[$defaultTime]"
        if (-not $time.Trim()) { $time = $defaultTime }
    } while ($time -notmatch '^([01]\d|2[0-3]):[0-5]\d$')
    $config.Schedule.Time = $time

    Write-Host '排程模式：'
    Write-Host '1. CopySafe 正式備份（建議）'
    Write-Host '2. MirrorSafe 只預覽，不移動檔案'
    Write-Host '3. MirrorSafe 自動執行（進階；仍受安全門檻保護）'
    $scheduleChoice = Read-Host '請選擇 [1]'
    if (-not $scheduleChoice.Trim()) { $scheduleChoice = '1' }
    if ($scheduleChoice -eq '2') {
        $config.Schedule.Mode = 'MirrorPreview'
        $config.MirrorSafety.AllowScheduledMirror = $false
    } elseif ($scheduleChoice -eq '3') {
        Write-AppWarn '自動鏡像會在排程時移動目標額外項目到 99_recycle。'
        $confirm = Read-Host '輸入 ENABLE AUTO MIRROR 才會啟用'
        if ($confirm -eq 'ENABLE AUTO MIRROR') {
            $config.Schedule.Mode = 'MirrorSafeAuto'
            $config.MirrorSafety.AllowScheduledMirror = $true
        } else {
            Write-AppWarn '確認字串不符，改用 MirrorSafe 預覽排程。'
            $config.Schedule.Mode = 'MirrorPreview'
            $config.MirrorSafety.AllowScheduledMirror = $false
        }
    } else {
        $config.Schedule.Mode = 'CopySafe'
        $config.MirrorSafety.AllowScheduledMirror = $false
    }
}

Save-AppConfig $config
Write-AppPass "設定已儲存：$script:ConfigPath"

if ($enableSchedule) { & (Join-Path $script:AppRoot 'Schedule_Manager.ps1') -Action Install }
else { & (Join-Path $script:AppRoot 'Schedule_Manager.ps1') -Action Remove -Quiet }

Write-Host ''
Write-AppInfo '開始環境驗證。'
& (Join-Path $script:AppRoot 'Backup.ps1') -Mode "$($config.SyncMode)" -ValidateOnly
if ($LASTEXITCODE -ne 0) { throw '環境驗證失敗。' }
Write-Host ''
if ($config.SyncMode -eq 'MirrorSafe') {
    Write-AppInfo '開始 MirrorSafe 預覽；不會複製、移動或刪除任何檔案。'
    & (Join-Path $script:AppRoot 'Backup.ps1') -Mode MirrorSafe -DryRun
} else {
    Write-AppInfo '開始 CopySafe 模擬；不會複製或刪除任何檔案。'
    & (Join-Path $script:AppRoot 'Backup.ps1') -Mode CopySafe -DryRun
}
if ($LASTEXITCODE -ne 0) { throw '安全模擬失敗。' }

Write-Host ''
if ($config.SyncMode -eq 'CopySafe') {
    if (Read-YesNo '設定及模擬都已通過，現在執行第一次 CopySafe 正式備份？' $false) {
        & (Join-Path $script:AppRoot 'Backup.ps1') -Mode CopySafe
    } else { Write-AppPass '設定完成；尚未執行正式備份。' }
} else {
    Write-AppPass 'MirrorSafe 設定與預覽完成。為安全起見，請回到主選單選擇「執行最新鏡像計畫」。'
}
