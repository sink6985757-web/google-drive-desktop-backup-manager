@echo off
setlocal
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Backup.ps1"
set "RC=%ERRORLEVEL%"
pause
exit /b %RC%
