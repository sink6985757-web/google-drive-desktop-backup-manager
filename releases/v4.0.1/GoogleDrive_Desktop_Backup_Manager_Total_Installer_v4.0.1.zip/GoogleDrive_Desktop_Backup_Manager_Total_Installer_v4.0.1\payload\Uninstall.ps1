﻿#requires -version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'Common.ps1')

function Get-GoogleDriveUninstallEntry {
    $paths = @(
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    return Get-ItemProperty $paths -ErrorAction SilentlyContinue |
        Where-Object { $_.DisplayName -eq 'Google Drive' -or $_.DisplayName -like 'Google Drive for desktop*' } |
        Select-Object -First 1
}

function Invoke-UninstallCommand([string]$Command) {
    if (-not $Command) { return $false }
    if ($Command -match '^\s*"([^"]+)"\s*(.*)$') { $exe = $matches[1]; $args = $matches[2] }
    elseif ($Command -match '^\s*([^\s]+)\s*(.*)$') { $exe = $matches[1]; $args = $matches[2] }
    else { return $false }
    if ($exe -match '(?i)msiexec(\.exe)?$') {
        $args = $args -replace '(?i)^\s*/I', '/X'
    }
    Start-Process -FilePath $exe -ArgumentList $args -Wait
    return $true
}

Write-Host ''
Write-Host '=== 解除安裝 ===' -ForegroundColor White
Write-Host '1. 只移除備份管理器（建議）'
Write-Host '2. 移除備份管理器，並啟動 Google Drive 解除安裝'
Write-Host '0. 取消'
$mode = Read-Host '請選擇'
if ($mode -eq '0' -or $mode -notin @('1','2')) { Write-AppInfo '已取消。'; exit 0 }

$confirm = Read-Host '輸入 UNINSTALL 確認移除備份管理器'
if ($confirm -ne 'UNINSTALL') { Write-AppInfo '已取消。'; exit 0 }

$preserve = (Read-Host '保留設定與日誌到「文件」資料夾？[Y/n]') -notmatch '^[Nn]'
if ($preserve) {
    $saveRoot = Join-Path ([Environment]::GetFolderPath('MyDocuments')) ('GoogleDriveBackupManager_Preserved_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
    New-Item -ItemType Directory -Path $saveRoot -Force | Out-Null
    foreach ($item in @('Backup_Config.json','logs','config_backups','state')) {
        $src = Join-Path $script:AppRoot $item
        if (Test-Path -LiteralPath $src) { Copy-Item -LiteralPath $src -Destination $saveRoot -Recurse -Force }
    }
    Write-AppPass "設定與日誌已保留：$saveRoot"
}

Unregister-ScheduledTask -TaskName $script:TaskName -Confirm:$false -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Google Drive Backup Manager.lnk') -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path ([Environment]::GetFolderPath('Programs')) 'Google Drive Backup Manager') -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\GoogleDriveDesktopBackupManager' -Recurse -Force -ErrorAction SilentlyContinue

if ($mode -eq '2') {
    Write-AppWarn '先確認 Google Drive 系統匣顯示同步完成；本程序不會刪除雲端檔案、備份目標或 DriveFS 使用者資料。'
    $driveConfirm = Read-Host '輸入 REMOVE GOOGLE DRIVE 才會繼續'
    if ($driveConfirm -eq 'REMOVE GOOGLE DRIVE') {
        Get-Process -Name GoogleDriveFS -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
        $entry = Get-GoogleDriveUninstallEntry
        $command = $null
        if ($entry) {
            if ($entry.PSObject.Properties['QuietUninstallString'] -and $entry.QuietUninstallString) { $command = $entry.QuietUninstallString }
            elseif ($entry.PSObject.Properties['UninstallString']) { $command = $entry.UninstallString }
        }
        if (-not $entry -or -not (Invoke-UninstallCommand $command)) {
            Write-AppWarn '找不到可自動執行的 Windows 解除安裝命令，已開啟「已安裝的應用程式」。'
            Start-Process 'ms-settings:appsfeatures'
        } else { Write-AppPass 'Google Drive 解除安裝程序已執行。' }
    } else { Write-AppInfo '已保留 Google Drive for desktop。' }
}

$cleanup = Join-Path $env:TEMP ('gddbm_cleanup_' + [guid]::NewGuid().ToString('N') + '.cmd')
$cmd = "@echo off`r`nping 127.0.0.1 -n 4 >nul`r`nrmdir /s /q `"$script:AppRoot`"`r`ndel /q `"%~f0`"`r`n"
Set-Content -LiteralPath $cleanup -Value $cmd -Encoding ASCII
Start-Process cmd.exe -ArgumentList "/c `"$cleanup`"" -WindowStyle Hidden
Write-AppPass '備份管理器解除安裝程序已啟動。'
