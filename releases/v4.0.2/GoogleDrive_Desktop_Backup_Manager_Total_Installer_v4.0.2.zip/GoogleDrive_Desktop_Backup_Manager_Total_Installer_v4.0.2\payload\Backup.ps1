﻿#requires -version 5.1
[CmdletBinding()]
param(
    [ValidateSet('Config','CopySafe','MirrorSafe')][string]$Mode = 'Config',
    [switch]$DryRun,
    [switch]$ValidateOnly,
    [switch]$NoVerify,
    [string]$ApprovePlanId = '',
    [switch]$AutoApprove,
    [switch]$Scheduled
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'Common.ps1')

foreach ($dir in @($script:LogsRoot,$script:StateRoot,$script:PlansRoot,$script:ManifestsRoot)) {
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
}
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$logPath = Join-Path $script:LogsRoot "backup_$stamp.log"

function Write-RunLog([string]$Level, [string]$Message) {
    $line = '[{0}] [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
    Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
    switch ($Level) {
        'PASS' { Write-Host $line -ForegroundColor Green }
        'WARN' { Write-Host $line -ForegroundColor Yellow }
        'ERROR' { Write-Host $line -ForegroundColor Red }
        default { Write-Host $line }
    }
}

function Invoke-Robocopy {
    param([string]$Source, [string]$Target, [string[]]$ExtraArguments, [string]$Label)
    $args = @($Source, $Target) + $ExtraArguments
    Write-RunLog 'INFO' "$Label：robocopy `"$Source`" `"$Target`" ..."
    & robocopy.exe @args | Out-Host
    $code = $LASTEXITCODE
    Write-RunLog 'INFO' "$Label：Robocopy ExitCode=$code"
    return $code
}

function Get-Inventory {
    param([string]$Root, [object]$MirrorSafety, [switch]$ApplyProtection)
    $entries = New-Object System.Collections.ArrayList
    if (-not (Test-Path -LiteralPath $Root -PathType Container)) {
        return [pscustomobject]@{ Root=$Root; Entries=@(); FileCount=0; DirectoryCount=0; TotalBytes=[int64]0; Signature=(Get-StringSha256 '') }
    }
    $items = Get-ChildItem -LiteralPath $Root -Force -Recurse -ErrorAction Stop |
        Where-Object { -not ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) }
    foreach ($item in $items) {
        $rel = Get-RelativeChildPath -Root $Root -FullName $item.FullName
        if ($ApplyProtection -and (Test-ProtectedRelativePath -RelativePath $rel -MirrorSafety $MirrorSafety)) { continue }
        $type = if ($item.PSIsContainer) { 'D' } else { 'F' }
        $length = if ($item.PSIsContainer) { [int64]0 } else { [int64]$item.Length }
        [void]$entries.Add([pscustomobject]@{
            Type = $type
            RelativePath = $rel
            Length = $length
            LastWriteUtcTicks = $item.LastWriteTimeUtc.Ticks
            FullName = $item.FullName
        })
    }
    $sorted = @($entries | Sort-Object -Property @{Expression={ $_.RelativePath }}, @{Expression={ $_.Type }})
    $lines = @($sorted | ForEach-Object { '{0}|{1}|{2}|{3}' -f $_.Type,$_.RelativePath,$_.Length,$_.LastWriteUtcTicks })
    $fileCount = @($sorted | Where-Object Type -eq 'F').Count
    $dirCount = @($sorted | Where-Object Type -eq 'D').Count
    $bytes = [int64](($sorted | Where-Object Type -eq 'F' | Measure-Object -Property Length -Sum).Sum)
    return [pscustomobject]@{
        Root = $Root
        Entries = $sorted
        FileCount = $fileCount
        DirectoryCount = $dirCount
        TotalBytes = $bytes
        Signature = Get-StringSha256 ($lines -join "`n")
    }
}

function New-MirrorSourcePlan {
    param([object]$SourceConfig, [string]$BackupRoot, [object]$MirrorSafety)
    $sourceRoot = Get-NormalizedPath "$($SourceConfig.LocalPath)"
    $targetRoot = Get-NormalizedPath (Join-Path $BackupRoot "$($SourceConfig.BackupFolder)")
    $sourceInv = Get-Inventory -Root $sourceRoot -MirrorSafety $MirrorSafety
    $targetInv = Get-Inventory -Root $targetRoot -MirrorSafety $MirrorSafety -ApplyProtection

    if ($targetInv.FileCount -gt 0 -and $sourceInv.FileCount -lt [int]$MirrorSafety.MinSourceFilesWhenTargetHasData) {
        throw "來源檔案數過低，已阻擋鏡像：$sourceRoot（來源 $($sourceInv.FileCount)，目標 $($targetInv.FileCount)）"
    }

    $sourceSet = New-Object -TypeName 'System.Collections.Generic.HashSet[string]' -ArgumentList ([StringComparer]::OrdinalIgnoreCase)
    foreach ($entry in $sourceInv.Entries) { [void]$sourceSet.Add("$($entry.Type)|$($entry.RelativePath)") }

    $missingDirs = @($targetInv.Entries | Where-Object { $_.Type -eq 'D' -and -not $sourceSet.Contains("D|$($_.RelativePath)") } | Sort-Object -Property @{Expression={ Get-PathDepth $_.RelativePath }}, @{Expression={ $_.RelativePath }})
    $selectedDirs = New-Object System.Collections.ArrayList
    foreach ($dir in $missingDirs) {
        $covered = $false
        foreach ($parent in $selectedDirs) {
            if (Test-RelativePathUnder -Child $dir.RelativePath -Parent $parent.RelativePath) { $covered = $true; break }
        }
        if (-not $covered) { [void]$selectedDirs.Add($dir) }
    }

    $candidates = New-Object System.Collections.ArrayList
    foreach ($dir in $selectedDirs) {
        $under = @($targetInv.Entries | Where-Object { $_.RelativePath -eq $dir.RelativePath -or (Test-RelativePathUnder -Child $_.RelativePath -Parent $dir.RelativePath) })
        $itemCount = $under.Count
        $fileCount = @($under | Where-Object Type -eq 'F').Count
        $bytes = [int64](($under | Where-Object Type -eq 'F' | Measure-Object -Property Length -Sum).Sum)
        [void]$candidates.Add([pscustomobject]@{ Type='Directory'; RelativePath=$dir.RelativePath; AffectedItems=$itemCount; AffectedFiles=$fileCount; Bytes=$bytes })
    }

    foreach ($file in @($targetInv.Entries | Where-Object { $_.Type -eq 'F' -and -not $sourceSet.Contains("F|$($_.RelativePath)") })) {
        $covered = $false
        foreach ($dir in $selectedDirs) {
            if (Test-RelativePathUnder -Child $file.RelativePath -Parent $dir.RelativePath) { $covered = $true; break }
        }
        if (-not $covered) {
            [void]$candidates.Add([pscustomobject]@{ Type='File'; RelativePath=$file.RelativePath; AffectedItems=1; AffectedFiles=1; Bytes=[int64]$file.Length })
        }
    }

    $affectedItems = [int](($candidates | Measure-Object -Property AffectedItems -Sum).Sum)
    $affectedFiles = [int](($candidates | Measure-Object -Property AffectedFiles -Sum).Sum)
    $affectedBytes = [int64](($candidates | Measure-Object -Property Bytes -Sum).Sum)
    $denominator = [Math]::Max(1, $targetInv.Entries.Count)
    $affectedPercent = [Math]::Round(($affectedItems * 100.0 / $denominator), 4)
    return [pscustomobject]@{
        LocalPath = $sourceRoot
        BackupFolder = "$($SourceConfig.BackupFolder)"
        TargetPath = $targetRoot
        SourceFileCount = $sourceInv.FileCount
        SourceDirectoryCount = $sourceInv.DirectoryCount
        SourceBytes = $sourceInv.TotalBytes
        SourceSignature = $sourceInv.Signature
        TargetFileCount = $targetInv.FileCount
        TargetDirectoryCount = $targetInv.DirectoryCount
        TargetBytes = $targetInv.TotalBytes
        TargetSignature = $targetInv.Signature
        AffectedItems = $affectedItems
        AffectedFiles = $affectedFiles
        AffectedBytes = $affectedBytes
        AffectedPercent = $affectedPercent
        Candidates = @($candidates | Sort-Object RelativePath)
    }
}

function New-MirrorPlan {
    param([object]$Config)
    $plans = New-Object System.Collections.ArrayList
    foreach ($source in @($Config.Sources | Where-Object { [bool]$_.Enabled })) {
        [void]$plans.Add((New-MirrorSourcePlan -SourceConfig $source -BackupRoot "$($Config.BackupRootPath)" -MirrorSafety $Config.MirrorSafety))
    }
    $totalItems = [int](($plans | Measure-Object -Property AffectedItems -Sum).Sum)
    $totalFiles = [int](($plans | Measure-Object -Property AffectedFiles -Sum).Sum)
    $totalBytes = [int64](($plans | Measure-Object -Property AffectedBytes -Sum).Sum)
    $maxPercent = [double](($plans | Measure-Object -Property AffectedPercent -Maximum).Maximum)
    $canonical = @($plans | ForEach-Object {
        $candidateText = @($_.Candidates | ForEach-Object { '{0}|{1}|{2}|{3}' -f $_.Type,$_.RelativePath,$_.AffectedItems,$_.Bytes }) -join ';'
        '{0}|{1}|{2}|{3}|{4}' -f $_.LocalPath,$_.TargetPath,$_.SourceSignature,$_.TargetSignature,$candidateText
    }) -join "`n"
    $planId = (Get-StringSha256 $canonical).Substring(0,16).ToUpperInvariant()
    $created = Get-Date
    $blockedReasons = New-Object System.Collections.ArrayList
    if ($totalItems -gt [int]$Config.MirrorSafety.MaxAffectedItems) {
        [void]$blockedReasons.Add("受影響項目 $totalItems 超過上限 $($Config.MirrorSafety.MaxAffectedItems)")
    }
    if ($maxPercent -gt [double]$Config.MirrorSafety.MaxAffectedPercent) {
        [void]$blockedReasons.Add("最大受影響比例 $maxPercent% 超過上限 $($Config.MirrorSafety.MaxAffectedPercent)%")
    }
    $limitBytes = [int64]([double]$Config.MirrorSafety.MaxRecycleBytesGB * 1073741824)
    if ($totalBytes -gt $limitBytes) {
        [void]$blockedReasons.Add("回收容量 $totalBytes bytes 超過上限 $limitBytes bytes")
    }
    return [pscustomobject]@{
        SchemaVersion = 1
        ApplicationVersion = $script:AppVersion
        PlanId = $planId
        CreatedAt = $created.ToString('o')
        ExpiresAt = $created.AddHours([double]$Config.MirrorSafety.PlanValidityHours).ToString('o')
        BackupRootPath = "$($Config.BackupRootPath)"
        TotalAffectedItems = $totalItems
        TotalAffectedFiles = $totalFiles
        TotalAffectedBytes = $totalBytes
        MaxAffectedPercent = $maxPercent
        IsBlocked = ($blockedReasons.Count -gt 0)
        BlockedReasons = @($blockedReasons)
        Sources = @($plans)
    }
}

function Save-MirrorPlan([object]$Plan) {
    $file = Join-Path $script:PlansRoot ("mirror_plan_{0}_{1}.json" -f (Get-Date -Format 'yyyyMMdd_HHmmss'),$Plan.PlanId)
    $latest = Join-Path $script:PlansRoot 'latest_mirror_plan.json'
    $Plan | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $file -Encoding UTF8
    Copy-Item -LiteralPath $file -Destination $latest -Force
    return $file
}

function Write-MirrorPlanSummary([object]$Plan) {
    Write-RunLog 'INFO' "MirrorSafe PlanId=$($Plan.PlanId)，受影響項目=$($Plan.TotalAffectedItems)，檔案=$($Plan.TotalAffectedFiles)，容量=$($Plan.TotalAffectedBytes) bytes，最大比例=$($Plan.MaxAffectedPercent)%"
    foreach ($sp in $Plan.Sources) {
        Write-RunLog 'INFO' "來源：$($sp.LocalPath) -> $($sp.TargetPath)；目標額外項目=$($sp.AffectedItems)，容量=$($sp.AffectedBytes) bytes"
        foreach ($candidate in @($sp.Candidates | Select-Object -First 100)) {
            Write-RunLog 'INFO' "  [$($candidate.Type)] $($candidate.RelativePath)；影響=$($candidate.AffectedItems)，容量=$($candidate.Bytes)"
        }
        if (@($sp.Candidates).Count -gt 100) { Write-RunLog 'WARN' '  候選超過 100 筆，完整清單請查看計畫 JSON。' }
    }
    foreach ($reason in @($Plan.BlockedReasons)) { Write-RunLog 'ERROR' "安全阻擋：$reason" }
}

function Move-CandidateToRecycle {
    param([string]$TargetRoot, [object]$Candidate, [string]$RecycleSnapshot)
    $sourcePath = Join-Path $TargetRoot "$($Candidate.RelativePath)"
    if (-not (Test-Path -LiteralPath $sourcePath)) { return }
    $destination = Join-Path $RecycleSnapshot "$($Candidate.RelativePath)"
    $destinationParent = Split-Path -Parent $destination
    New-Item -ItemType Directory -Path $destinationParent -Force | Out-Null
    if (Test-Path -LiteralPath $destination) {
        $destination = $destination + '.conflict_' + [guid]::NewGuid().ToString('N')
    }
    Move-Item -LiteralPath $sourcePath -Destination $destination -Force
    Write-RunLog 'PASS' "已移入回收區：$sourcePath -> $destination"
}

function Save-RunManifest {
    param([object]$Config, [string]$RunMode, [string]$Status, [object]$Plan = $null)
    $manifest = [pscustomobject]@{
        ApplicationVersion = $script:AppVersion
        Timestamp = (Get-Date).ToString('o')
        Mode = $RunMode
        Status = $Status
        BackupRootPath = "$($Config.BackupRootPath)"
        PlanId = if ($Plan) { "$($Plan.PlanId)" } else { '' }
        Sources = @($Config.Sources | Where-Object { [bool]$_.Enabled } | ForEach-Object {
            [pscustomobject]@{ LocalPath="$($_.LocalPath)"; BackupFolder="$($_.BackupFolder)" }
        })
    }
    $path = Join-Path $script:ManifestsRoot ("run_{0}_{1}.json" -f (Get-Date -Format 'yyyyMMdd_HHmmss'),$RunMode)
    $manifest | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $path -Encoding UTF8
    Write-RunLog 'INFO' "執行清單：$path"
}

$mutex = New-Object System.Threading.Mutex($false, 'Local\GoogleDrive_Desktop_Backup_Manager_Run')
$locked = $false
try {
    $locked = $mutex.WaitOne(0)
    if (-not $locked) { throw '另一個備份工作正在執行。' }
    Write-RunLog 'INFO' '=== Google Drive Desktop Backup Manager v4 開始 ==='
    $config = Get-AppConfig
    if ([int]$config.SchemaVersion -ne 4) { throw '設定檔版本不正確，請重新執行安裝或設定精靈。' }
    if ($Mode -eq 'Config') { $Mode = "$($config.SyncMode)" }
    if ($Mode -notin @('CopySafe','MirrorSafe')) { throw "不支援的模式：$Mode" }

    [void](Start-GoogleDriveIfNeeded)
    if (-not (Get-Process -Name GoogleDriveFS -ErrorAction SilentlyContinue)) { throw 'Google Drive 程式未正常執行。' }
    Write-RunLog 'PASS' 'Google Drive 程式正在執行。'

    $backupRoot = "$($config.BackupRootPath)"
    if (-not $backupRoot) { throw '尚未設定 BackupRootPath。' }
    if (-not (Test-WritableFolder $backupRoot)) { throw "備份根目錄不存在或無法寫入：$backupRoot" }
    Write-RunLog 'PASS' "備份根目錄可寫入：$backupRoot"

    $sources = @($config.Sources | Where-Object { [bool]$_.Enabled })
    if ($sources.Count -eq 0) { throw '沒有啟用的來源資料夾。' }
    foreach ($source in $sources) {
        if (-not (Test-Path -LiteralPath $source.LocalPath -PathType Container)) { throw "來源不存在：$($source.LocalPath)" }
        $target = Join-Path $backupRoot "$($source.BackupFolder)"
        if (Test-PathOverlap -PathA $source.LocalPath -PathB $target) { throw "來源與目標重疊：$($source.LocalPath) <-> $target" }
        if ("$($source.BackupFolder)".Equals("$($config.MirrorSafety.RecycleFolderName)", [StringComparison]::OrdinalIgnoreCase)) {
            throw "來源目標名稱不得使用回收區名稱：$($source.BackupFolder)"
        }
        Write-RunLog 'PASS' "來源存在：$($source.LocalPath)"
    }

    if ($ValidateOnly) {
        Save-RunManifest -Config $config -RunMode $Mode -Status 'VALIDATED'
        Write-RunLog 'PASS' '環境、設定與寫入權限驗證完成；未複製、移動或刪除任何檔案。'
        exit 0
    }

    $copy = $config.CopyOptions
    $baseArgs = @(
        '/E', '/COPY:DAT', '/DCOPY:T', '/XJ', '/FFT',
        "/R:$([int]$copy.Retries)", "/W:$([int]$copy.WaitSeconds)",
        "/MT:$([int]$copy.Threads)", '/NP', '/TEE', "/LOG+:$logPath"
    )

    if ($Mode -eq 'CopySafe') {
        if ($DryRun) { $baseArgs += '/L' }
        foreach ($source in $sources) {
            $target = Join-Path $backupRoot "$($source.BackupFolder)"
            New-Item -ItemType Directory -Path $target -Force | Out-Null
            $code = Invoke-Robocopy -Source "$($source.LocalPath)" -Target $target -ExtraArguments $baseArgs -Label 'CopySafe'
            if ($code -ge 8) { throw "Robocopy CopySafe 失敗：$($source.LocalPath)，ExitCode=$code" }
            if ($DryRun) {
                Write-RunLog 'PASS' "CopySafe 模擬完成：$($source.LocalPath) -> $target；未寫入、移動或刪除檔案。"
                continue
            }
            Write-RunLog 'PASS' "CopySafe 複製完成：$($source.LocalPath) -> $target"
            if (-not $NoVerify -and [bool]$config.VerifyAfterCopy) {
                $verifyArgs = @('/E','/L','/COPY:DAT','/DCOPY:T','/XJ','/FFT','/R:0','/W:0','/NJH','/NJS','/NP','/NS','/NC','/NDL','/NFL')
                $verifyCode = Invoke-Robocopy -Source "$($source.LocalPath)" -Target $target -ExtraArguments $verifyArgs -Label 'CopySafe 驗證'
                if ($verifyCode -notin @(0,2)) { throw "驗證發現尚待複製或不一致項目：$($source.LocalPath)，ExitCode=$verifyCode" }
                Write-RunLog 'PASS' "CopySafe 驗證通過：$($source.LocalPath)"
            }
        }
        Save-RunManifest -Config $config -RunMode $Mode -Status $(if ($DryRun) {'DRY_RUN'} else {'PASS'})
        if ($DryRun) { Write-RunLog 'PASS' '=== CopySafe 模擬完成，沒有寫入或刪除檔案 ===' }
        else { Write-RunLog 'PASS' '=== CopySafe 全部複製與驗證完成 ===' }
        exit 0
    }

    $plan = New-MirrorPlan -Config $config
    $planPath = Save-MirrorPlan -Plan $plan
    Write-MirrorPlanSummary -Plan $plan
    Write-RunLog 'INFO' "鏡像計畫已儲存：$planPath"

    if ($plan.IsBlocked) {
        Save-RunManifest -Config $config -RunMode $Mode -Status 'BLOCKED' -Plan $plan
        throw 'MirrorSafe 計畫超過安全上限，已阻擋。請檢查來源路徑、移動內容或調整安全門檻後重新預覽。'
    }

    if ($DryRun) {
        Save-RunManifest -Config $config -RunMode $Mode -Status 'DRY_RUN' -Plan $plan
        Write-RunLog 'PASS' "=== MirrorSafe 預覽完成；PlanId=$($plan.PlanId)，沒有寫入、移動或刪除檔案 ==="
        exit 0
    }

    if ($AutoApprove) {
        if (-not $Scheduled -or -not [bool]$config.MirrorSafety.AllowScheduledMirror) {
            throw 'AutoApprove 只允許已明確啟用的排程安全鏡像使用。'
        }
        Write-RunLog 'WARN' '已啟用排程自動鏡像；本次仍受數量、比例、容量與來源完整性門檻保護。'
    } elseif ([bool]$config.MirrorSafety.RequirePlanApproval) {
        if (-not $ApprovePlanId) { throw "MirrorSafe 需要核准計畫。請先預覽，再使用 PlanId=$($plan.PlanId) 執行。" }
        if (-not $ApprovePlanId.Equals("$($plan.PlanId)", [StringComparison]::OrdinalIgnoreCase)) {
            throw "核准 PlanId 不符或來源／目標已變更。輸入=$ApprovePlanId，目前=$($plan.PlanId)。請重新預覽。"
        }
        if ((Get-Date) -gt [datetime]$plan.ExpiresAt) { throw '鏡像計畫已過期，請重新預覽。' }
    }

    $recycleRoot = Join-Path $backupRoot "$($config.MirrorSafety.RecycleFolderName)"
    $snapshotRoot = Join-Path $recycleRoot ("GDDM_MirrorSafe\$stamp`_$($plan.PlanId)")
    foreach ($sourcePlan in $plan.Sources) {
        $sourceRecycle = Join-Path $snapshotRoot "$($sourcePlan.BackupFolder)"
        foreach ($candidate in $sourcePlan.Candidates) {
            Move-CandidateToRecycle -TargetRoot "$($sourcePlan.TargetPath)" -Candidate $candidate -RecycleSnapshot $sourceRecycle
        }
    }

    foreach ($source in $sources) {
        $target = Join-Path $backupRoot "$($source.BackupFolder)"
        New-Item -ItemType Directory -Path $target -Force | Out-Null
        $code = Invoke-Robocopy -Source "$($source.LocalPath)" -Target $target -ExtraArguments $baseArgs -Label 'MirrorSafe 複製'
        if ($code -ge 8) { throw "Robocopy MirrorSafe 複製失敗：$($source.LocalPath)，ExitCode=$code" }
    }

    if (-not $NoVerify -and [bool]$config.VerifyAfterCopy) {
        $verifyPlan = New-MirrorPlan -Config $config
        if ($verifyPlan.TotalAffectedItems -ne 0) {
            $verifyPath = Save-MirrorPlan -Plan $verifyPlan
            throw "MirrorSafe 驗證仍發現目標額外項目 $($verifyPlan.TotalAffectedItems)；驗證計畫：$verifyPath"
        }
        foreach ($source in $sources) {
            $target = Join-Path $backupRoot "$($source.BackupFolder)"
            $verifyArgs = @('/E','/L','/COPY:DAT','/DCOPY:T','/XJ','/FFT','/R:0','/W:0','/NJH','/NJS','/NP','/NS','/NC','/NDL','/NFL')
            $verifyCode = Invoke-Robocopy -Source "$($source.LocalPath)" -Target $target -ExtraArguments $verifyArgs -Label 'MirrorSafe 驗證'
            if ($verifyCode -notin @(0,2)) { throw "MirrorSafe 驗證發現尚待複製或不一致項目：$($source.LocalPath)，ExitCode=$verifyCode" }
        }
        Write-RunLog 'PASS' 'MirrorSafe 精確性驗證通過。'
    }

    Save-RunManifest -Config $config -RunMode $Mode -Status 'PASS' -Plan $plan
    Write-RunLog 'PASS' "=== MirrorSafe 完成；舊位置已移入 $snapshotRoot，未永久刪除 ==="
    Write-RunLog 'INFO' 'Google 雲端實際上傳與移動由 Drive for desktop 背景完成；請確認系統匣顯示同步完成。'
    exit 0
}
catch {
    Write-RunLog 'ERROR' $_.Exception.Message
    Write-RunLog 'ERROR' "日誌：$logPath"
    exit 1
}
finally {
    if ($locked) { $mutex.ReleaseMutex() }
    $mutex.Dispose()
    try {
        $cfg = Get-AppConfig
        $days = [int]$cfg.LogRetentionDays
        if ($days -lt 1) { $days = 60 }
        Get-ChildItem -LiteralPath $script:LogsRoot -Filter '*.log' -File -ErrorAction SilentlyContinue |
            Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-$days) } |
            Remove-Item -Force -ErrorAction SilentlyContinue
    } catch { }
}
