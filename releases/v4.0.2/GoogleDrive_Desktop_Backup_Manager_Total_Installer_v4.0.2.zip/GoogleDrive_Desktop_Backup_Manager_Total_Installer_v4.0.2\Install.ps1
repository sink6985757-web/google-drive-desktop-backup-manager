﻿#requires -version 5.1
[CmdletBinding()]
param(
    [string]$InstallRoot = "$env:LOCALAPPDATA\GoogleDriveDesktopBackupManager",
    [switch]$Fresh,
    [switch]$SkipGoogleDriveInstall,
    [switch]$SkipWizard
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$Version = '4.0.2'
$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$PayloadRoot = Join-Path $PackageRoot 'payload'
$DriveSetupUrl = 'https://dl.google.com/drive-file-stream/GoogleDriveSetup.exe'

function Write-Info([string]$Text) { Write-Host "[INFO] $Text" -ForegroundColor Cyan }
function Write-Pass([string]$Text) { Write-Host "[PASS] $Text" -ForegroundColor Green }
function Write-Warn([string]$Text) { Write-Host "[WARN] $Text" -ForegroundColor Yellow }

function Get-GoogleDriveExe {
    $roots = @(
        (Join-Path $env:ProgramFiles 'Google\Drive File Stream'),
        (Join-Path $env:LOCALAPPDATA 'Google\DriveFS')
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
    foreach ($root in $roots) {
        $exe = Get-ChildItem -LiteralPath $root -Filter 'GoogleDriveFS.exe' -File -Recurse -ErrorAction SilentlyContinue |
            Sort-Object { $_.Directory.Name } -Descending | Select-Object -First 1
        if ($exe) { return $exe.FullName }
    }
    return $null
}

function Install-GoogleDriveDesktop {
    $existing = Get-GoogleDriveExe
    if ($existing) { Write-Pass "Google 雲端硬碟電腦版已安裝：$existing"; return }
    if ($SkipGoogleDriveInstall) { Write-Warn '已略過 Google 雲端硬碟電腦版安裝。'; return }

    Write-Info '正在從 Google 官方下載 GoogleDriveSetup.exe...'
    $tempDir = Join-Path $env:TEMP ('gddbm_setup_' + [guid]::NewGuid().ToString('N'))
    $setup = Join-Path $tempDir 'GoogleDriveSetup.exe'
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -UseBasicParsing -Uri $DriveSetupUrl -OutFile $setup
        $sig = Get-AuthenticodeSignature -FilePath $setup
        if ($sig.Status -ne 'Valid') { throw "Google 安裝檔數位簽章無效：$($sig.Status)" }
        if (-not $sig.SignerCertificate -or $sig.SignerCertificate.Subject -notmatch 'Google') {
            throw "安裝檔簽署者不是 Google：$($sig.SignerCertificate.Subject)"
        }
        Write-Pass "Google 數位簽章驗證通過：$($sig.SignerCertificate.Subject)"
        $p = Start-Process -FilePath $setup -ArgumentList '--silent --desktop_shortcut' -Wait -PassThru
        if ($p.ExitCode -notin @(0, 3010)) { throw "Google Drive 安裝失敗，ExitCode=$($p.ExitCode)" }
        $installed = $null
        for ($i = 0; $i -lt 30 -and -not $installed; $i++) {
            Start-Sleep -Seconds 1
            $installed = Get-GoogleDriveExe
        }
        if (-not $installed) { throw '安裝程序已結束，但 30 秒內找不到 GoogleDriveFS.exe。' }
        Write-Pass "Google 雲端硬碟電腦版安裝完成：$installed"
    }
    finally { Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue }
}

function New-Shortcut {
    param([string]$Path, [string]$Target, [string]$Arguments = '', [string]$WorkingDirectory = '')
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($Path)
    $shortcut.TargetPath = $Target
    $shortcut.Arguments = $Arguments
    if ($WorkingDirectory) { $shortcut.WorkingDirectory = $WorkingDirectory }
    $shortcut.Save()
}

if (-not (Test-Path -LiteralPath $PayloadRoot)) { throw "安裝包不完整：找不到 $PayloadRoot" }
Write-Host ''
Write-Host "Google Drive Desktop Backup Manager v$Version - MirrorSafe" -ForegroundColor White
Write-Host '官方 Google Drive + Windows Robocopy；不需要 rclone 或自建 OAuth。'

if (-not $PSBoundParameters.ContainsKey('InstallRoot')) {
    $inputPath = Read-Host "安裝路徑 [$InstallRoot]"
    if ($inputPath.Trim()) { $InstallRoot = $inputPath.Trim().TrimEnd('\') }
}

Install-GoogleDriveDesktop

Write-Info "正在安裝備份管理器：$InstallRoot"
$parent = Split-Path -Parent $InstallRoot
New-Item -ItemType Directory -Path $parent -Force | Out-Null

if (Test-Path -LiteralPath $InstallRoot) {
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $snapshot = Join-Path $parent ("GoogleDriveDesktopBackupManager_PreInstall_$stamp")
    New-Item -ItemType Directory -Path $snapshot -Force | Out-Null
    foreach ($item in @('Backup_Config.json','logs','state','config_backups')) {
        $src = Join-Path $InstallRoot $item
        if (Test-Path -LiteralPath $src) { Copy-Item -LiteralPath $src -Destination $snapshot -Recurse -Force }
    }
    Write-Pass "舊設定／日誌已備份：$snapshot"
}

New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null
Get-ChildItem -LiteralPath $PayloadRoot -File | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $InstallRoot $_.Name) -Force
}
foreach ($dir in @('logs','config_backups','state','state\plans','state\manifests')) { New-Item -ItemType Directory -Path (Join-Path $InstallRoot $dir) -Force | Out-Null }

$configPath = Join-Path $InstallRoot 'Backup_Config.json'
$defaultPath = Join-Path $InstallRoot 'Backup_Config.default.json'
if ($Fresh -or -not (Test-Path -LiteralPath $configPath)) {
    Copy-Item -LiteralPath $defaultPath -Destination $configPath -Force
    Write-Pass '已建立全新設定檔。'
} else {
    try {
        $cfg = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if (-not $cfg.PSObject.Properties['SchemaVersion']) {
            throw '設定檔缺少 SchemaVersion。'
        }
        $schema = [int]$cfg.SchemaVersion
        if ($schema -eq 3) {
            $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
            Copy-Item -LiteralPath $configPath -Destination (Join-Path $InstallRoot "config_backups\Backup_Config_pre_v4_$stamp.json") -Force
            $cfg.SchemaVersion = 4
            $cfg.ApplicationVersion = $Version
            if (-not $cfg.PSObject.Properties['SyncMode']) { $cfg | Add-Member -NotePropertyName SyncMode -NotePropertyValue 'CopySafe' }
            $mirror = [pscustomobject]@{
                RequirePlanApproval = $true
                PlanValidityHours = 24
                MaxAffectedItems = 20
                MaxAffectedPercent = 2.0
                MaxRecycleBytesGB = 5.0
                MinSourceFilesWhenTargetHasData = 1
                RecycleFolderName = '99_recycle'
                RecycleRetentionDays = 90
                AutoPurgeRecycle = $false
                AllowScheduledMirror = $false
                ProtectedNames = @('sync.ffs_db', '.tmp.driveupload')
            }
            $cfg | Add-Member -NotePropertyName MirrorSafety -NotePropertyValue $mirror -Force
            if (-not $cfg.Schedule.PSObject.Properties['Mode']) { $cfg.Schedule | Add-Member -NotePropertyName Mode -NotePropertyValue 'CopySafe' }
            $cfg | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $configPath -Encoding UTF8
            Write-Pass '已保留來源、目標與排程，並將 v3 設定安全升級為 v4；預設仍為 CopySafe。'
        } elseif ($schema -eq 4) {
            $cfg.ApplicationVersion = $Version
            $cfg | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $configPath -Encoding UTF8
            Write-Pass '已保留並更新現有 v4 設定檔。'
        } else {
            throw "不支援直接升級的設定版本：$schema"
        }
    } catch {
        $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
        Copy-Item -LiteralPath $configPath -Destination (Join-Path $InstallRoot "config_backups\Backup_Config_invalid_for_v4_$stamp.json") -Force
        Copy-Item -LiteralPath $defaultPath -Destination $configPath -Force
        Write-Warn '舊設定無法解析或不支援直接升級，已備份並重建 v4 CopySafe 安全設定。'
    }
}

$launcher = Join-Path $InstallRoot 'Launch_Manager.cmd'
$desktop = [Environment]::GetFolderPath('Desktop')
$startMenu = Join-Path ([Environment]::GetFolderPath('Programs')) 'Google Drive Backup Manager'
New-Item -ItemType Directory -Path $startMenu -Force | Out-Null
New-Shortcut -Path (Join-Path $desktop 'Google Drive Backup Manager.lnk') -Target $launcher -WorkingDirectory $InstallRoot
New-Shortcut -Path (Join-Path $startMenu 'Google Drive Backup Manager.lnk') -Target $launcher -WorkingDirectory $InstallRoot
New-Shortcut -Path (Join-Path $startMenu '解除安裝 Google Drive Backup Manager.lnk') -Target (Join-Path $InstallRoot 'Uninstall.cmd') -WorkingDirectory $InstallRoot

$uninstallKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\GoogleDriveDesktopBackupManager'
New-Item -Path $uninstallKey -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name DisplayName -Value 'Google Drive Desktop Backup Manager' -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name DisplayVersion -Value $Version -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name Publisher -Value 'Local installation package' -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name InstallLocation -Value $InstallRoot -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name UninstallString -Value ('"' + (Join-Path $InstallRoot 'Uninstall.cmd') + '"') -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name NoModify -Value 1 -PropertyType DWord -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name NoRepair -Value 1 -PropertyType DWord -Force | Out-Null

$driveExe = Get-GoogleDriveExe
if ($driveExe -and -not (Get-Process -Name GoogleDriveFS -ErrorAction SilentlyContinue)) {
    Start-Process -FilePath $driveExe | Out-Null
}

Write-Pass '備份管理器安裝完成。'
if (-not $SkipWizard) {
    Write-Info '即將啟動首次設定精靈。Google 帳號登入必須由本人在 Google 官方視窗完成。'
    if ($Fresh) { & (Join-Path $InstallRoot 'Configure.ps1') -FirstRun } else { & (Join-Path $InstallRoot 'Configure.ps1') }
}
Write-Host ''
Write-Pass "完成。可從桌面開啟：Google Drive Backup Manager"
